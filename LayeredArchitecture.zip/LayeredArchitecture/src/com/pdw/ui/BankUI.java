package com.pdw.ui;
import java.util.Scanner;
import com.capg.bank.Bank;
import com.capg.bank.service.Service;
import com.capg.bank.service.ServiceClass;
public class BankUI {
	private static Service service=new Serviceclass();
	private static Scanner sc=new Scanner(System.in); 
	public static void main(String[] args) {
		int i=0;
		do
		{
			System.out.println("Enter the choice \n 1.Create Account \n 2.show Balance \n 3.Deposit \n 4.Withdraw 5.FundTransfer \n 6.Print Transaction \n 7.Exit");
			int n=sc.nextInt();
			switch(n)
			{
			case 1:
				service.createAccount();
				break;
			case 2:
				service.showBalance();
				break;
			case 3:
				service.deposit();
				break;
			case 4:
				service.withDraw();
				break;
			case 5:
				service.fundTransfer();
				break;
			case 6:
				service.printTransaction();
				break;
			case 7:
				System.exit(0);
			}
			System.out.println("Do you want to continue :1.CONTINUE \t 2.END");
			i=sc.nextInt();
			
			}
		while(i==1);
	}

}
