package com.pdw.service;
import java.util.Scanner;

import com.pdw.dao.Daoclass;

public class ServiceClass implements BankService {
	private Daoclass dao=new Daoclass();
	private Scanner sc=new Scanner(System.in);
	public void createAccount()
	
	{
		System.out.println("\n Enter your details to Create Account:");
		System.out.println("Enter username");
		b.setUserName(sc.next());
		b.setAccNo();
		b.setBalance();
		dao.createAccount(b);
	}
	public void showBalance()
	{
		System.out.println("Enter Your Account No");
		int accNO=sc.nextInt();
		return dao.showBalance(accNO);
	}
	public void deposit()
	{
		System.out.println("Enter The Account NO");
		int accNO=sc.nextInt();
		System.out.println("Enter The Amount to be Deposited");
		int amt=sc.nextInt();
		dao.deposit(accNO,amt);
	}
	public void withDraw()
	{
		System.out.println("Enter The Account NO");
		int accNO=sc.nextInt();
		System.out.println("Enter The Amount to be withdraw");
		int amt=sc.nextInt();
		dao.withdraw(accNO,amt);
	}
	public void fundTransfer()
	{
		System.out.println("Enter The Account NO");
		int accNO=sc.nextInt();
		System.out.println("Enter The Amount to be Transfered");
		int accNOto=sc.nextInt();
		System.out.println("Enter the Amount to be tranfered");
		int amt=sc.nextInt();
		dao.fundTransfer(accNO,accNOto,amt);
	}
	public void accountNumberValidate(int accNO)
	{
	
}
