package com.pdw.service;

public interface Service {
	void accountNumberValidate(int accNO);
	void createAccount();
	void showBalance();
	void deposit();
	void withDraw();
	void fundTransfer();

}
