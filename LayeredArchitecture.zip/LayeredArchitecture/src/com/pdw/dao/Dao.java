package com.pdw.dao;

public interface Dao {

}
