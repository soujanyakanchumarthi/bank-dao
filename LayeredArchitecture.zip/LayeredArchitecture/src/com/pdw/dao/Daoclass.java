package com.pdw.dao;
import java.util.ArrayList;
import java.util.List;
import com.capg.bank.Bank;
import java.text.DateFormat;
import java.util.Date;

public class DaoClass implements dao{
	private static List<Bank>l1=new ArrayList<Bank>();
	static
	{
		Bank b1=new Bank("manvi",1000,123);
		Bank b2=new Bank("souji",1001,12);
		Bank b3=new Bank("Deepika",1002,130);
		l1.add(b1);
		l1.add(b2);
	}
	public void createAccount(Bank b)
	{
		l1.add(b);
		System.out.println(b);
		
	}
	public Bank showbalance(int accNO) {
		Bank b=new Bank();
		for(Bank b1:l1)
		{
			if(b1.getAccNo()==accNO)
			{
				b=b1;
				break;
			}
				
		}
		public void deposit(int accNO) {
			Bank b=new Bank();
			for(Bank b1:l1)
			{
				if(b1.getAccNo()==accNO)
				{
					b=b1;
					break;
				}
					
			}
			b.setBalance(b.getBalance()+amt);
			System.out.println("amount succesfully deposited");
			System.out.println("your new balance:"+getBalance());
	}
		public voiod withDraw(int accNO,int amt)
		{
			Bank b=new Bank();
			for(Bank b1:l1) {
				if(b1.getAccNo()==accNO)
			{
					b=b1;
					break;
			}
				
			}
		if(b.getBalance()>amt)
		{
			b.setBalance(b.getBalance()-amt);
			System.out.println("amount succesfully withdrawn");
		
			
	
		}
		else
		{
			System.out.println("you have insufficient funds");
		}
		}
		public void fundTranfer(int accNO,int amt)
		{
			Bank b=new Bank();
			for(Bank b1:l1) {
				if(b1.getAccNo()==accNO)
			{
					b=b1;
					break;
			}
			
		
		}
			Bank b2=new Bank();
			for(Bank bt : l1)
			{
				if(bt.getAccNo()==accNOto)
					
				{
					b2=bt;
					if(b2==null)
						System.out.println("Accountno not found");
					break;
				}
					}
			if(b.getBalance()>amt)
			{
				b.setBalance(b.getBalance()-amt);
				System.out.println("amount succesfully withdrawn and credited to new account");
				System.out.println("your new balance :"+b.getBalance());
				b2.setBalance(b2.getBalance()+amt);
				else
				{
					System.out.println("you have insufficient funds to transfer");
				
				}
				}
				}
			
	

}