package com.pdw.bean;

public class BankBean {

}
